My Drive Icon a freeware by LeeLu Soft 2008 v1.0
------------------------------------------------

My Drive Icon is a small and simple utility that let you easily change the default drives icons or restore the defult icons in a simple and safe way.


How to use My Drive Icon
------------------------
My Drive Icon is a portable application, after the first installation you can copy the executable (DI.exe) and use it on any computer or run it directly from a USB drive or stick without any installation.

My Drive Icon interface is very simple, so it is easy to use it.

First thing is to select your new icon file, enter or browse and select the icon file.
Now from the drives dropbox select the drive that you want to change it's icon.
You can enter a new lable for this drive.

Now click on Aplly Changes, go to My Computer and if needed press F5 to refresh the view and here is you new icon.
To roll back to the default icon, select the drive (from the dropbox) and click Restore Defaults.

That's all.


OS Support
----------
My Drive Icon was tested on Microsoft Windows 7 and XP.


LeeLu Soft Freeware License
---------------------------

Copyright � 2008 by LeeLu Soft <zvika.israeli@gmail.com>. All rights reserved

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 

http://leelusoft.blogspot.com


