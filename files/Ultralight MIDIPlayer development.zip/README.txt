超軽量MIDIプレイヤー (UMP) by PipiraMine

#Line  Language
    7  にほんご
   59  English

マニュアル

  起動方法から設定の解説、上手な使い方までUMPのすべての情報はUMPマニュアルに
  記載されています。ご一読ください。

  https://pipiraworld.web.fc2.com/manual/ja.html

  このREADME.txtファイルは、インターネットがなくマニュアルを読めない方向けに
  マニュアルの一部を抜粋したものです。

起動方法

  Windows

    MIDIPlayer.batをダブルクリックで起動します。

  他のOS

    ターミナルから起動します。

    $ java -jar MIDIPlayer.jar

Java

  "Javaが見つからない"的なメッセージ (英語かもしれません) が出て起動しない場合は
  Javaをインストールしてください。Javaはたくさんあり、基本は何を入れてもいいの
  ですが、PCが64ビットの方は64ビット版とはっきり書かれているものをインストール
  しましょう。

WinMMパッチ

  Windows 8以降ではUMPを含む多くのMIDIプレイヤーが全然軽量じゃなくなります。
  これを解決するパッチというものがあります。忘れないうちにしておきましょう。

  UMPに限りパッチの方法が特殊です。マニュアルを見ながら進めてください。
  (MIDIPlayerファイルはパッチできません！Javaをパッチです！)

  https://pipiraworld.web.fc2.com/ump/manual/ja.html#Tutorials/Apply-WinMM-Patch

ライセンス

  ジャンルとしてはいわゆるプロプライエタリってやつ (自称) で、
  商用利用、リバースエンジニアリング、改変などもろもろ禁止しています。
  やっていいことについてはLICENSE.txtをご覧ください。

お問い合わせ

  機能提案・バグ報告など作者へのお便りは利用者専用Discordで受け付けています。
  UMP内で[ヘルプ]→[でぃすこぉど]から参加してね。



UMP Manual

  All information about UMP, from setup to settings and tips, can be found in
  the UMP manual.  Please have a read.

  https://pipiraworld.web.fc2.com/manual/en.html

  This README.txt file is a snippet of the manual for those who do not have
  internet access and cannot read the manual.

Getting Started

  Windows

    Double-click MIDIPlayer.bat to start UMP.

  Other OS

    Use terminal.

    $ java -jar MIDIPlayer.jar

Java

  If you get a "Java not found" kind of message and UMP doesn't start, you need
  to install Java.  Java is available from many sources, and basically you can
  install any one of them.  However, if your PC is 64-bit, install the one that
  is clearly marked as a 64-bit version.

WinMM Patch

  Many MIDI players, including UMP, performs worse on Windows 8 or later.
  There is a patch to fix this.  Make sure you do it before you forget.

  The patching method is unique to UMP.  Please refer to the manual as you proceed.
  (MIDIPlayer files can't be patched! Patch Java!)

  https://pipiraworld.web.fc2.com/ump/manual/en.html#Tutorials/Apply-WinMM-Patch

License

  UMP is licensed under the UMP License 2.0.
  It's basically a proprietary license, which means you're not allowed to use
  UMP commercially, reverse engineer, modify, etc.
  To see what's allowed, read LICENSE.txt file.

Contact Us

  Suggestions and bug reports are welcomed on Discord server (users exclusive).
  Go [Help] -> [Discord server] to join.



© 2025 PipiraMine
