// 🕒 CRONÔMETRO COM CENTÉSIMOS
let inicioCrono = null;
let acumuladoCrono = 0;
let intervaloCrono = null;

function formatarCrono(ms) {
  const totalSeg = Math.floor(ms / 1000);
  const h = String(Math.floor(totalSeg / 3600)).padStart(2, '0');
  const m = String(Math.floor((totalSeg % 3600) / 60)).padStart(2, '0');
  const s = String(totalSeg % 60).padStart(2, '0');
  const cs = String(Math.floor((ms % 1000) / 10)).padStart(2, '0');
  return `${h}:${m}:${s}.${cs}`;
}

function atualizarCrono() {
  const agora = Date.now();
  const decorrido = acumuladoCrono + (agora - inicioCrono);
  document.getElementById('cronometro').textContent = formatarCrono(decorrido);
}

function iniciarCrono() {
  if (!intervaloCrono) {
    inicioCrono = Date.now();
    intervaloCrono = setInterval(atualizarCrono, 10);
  }
}

function pausarCrono() {
  if (intervaloCrono) {
    acumuladoCrono += Date.now() - inicioCrono;
    clearInterval(intervaloCrono);
    intervaloCrono = null;
  }
}

function zerarCrono() {
  pausarCrono();
  acumuladoCrono = 0;
  document.getElementById('cronometro').textContent = '00:00:00.00';
}

// ⏳ TEMPORIZADOR SEM MILISSEGUNDOS
let tempSegundos = 30;
let intervaloTemp;

function formatarTempo(seg) {
  const h = String(Math.floor(seg / 3600)).padStart(2, '0');
  const m = String(Math.floor((seg % 3600) / 60)).padStart(2, '0');
  const s = String(seg % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

function configurarTemp() {
  const min = parseInt(document.getElementById('minutosInput').value);
  const seg = parseInt(document.getElementById('segundosInput').value);

  if (
    isNaN(min) || isNaN(seg) ||
    min < 0 || min > 59 ||
    seg < 0 || seg > 59
  ) {
    alert("Digite valores válidos: 0–59 minutos e 0–59 segundos.");
    return;
  }

  const total = min * 60 + seg;
  if (total < 1 || total > 3599) {
    alert("Escolha um tempo entre 1 segundo e no máximo 59:59.");
    return;
  }

  tempSegundos = total;
  document.getElementById('temporizador').textContent = formatarTempo(tempSegundos);
}

function atualizarTemp() {
  if (tempSegundos > 0) {
    tempSegundos--;
    document.getElementById('temporizador').textContent = formatarTempo(tempSegundos);
  } else {
    clearInterval(intervaloTemp);
    alert("⏰ Tempo esgotado!");
    resetarTemp();
  }
}

function iniciarTemp() {
  if (!intervaloTemp) intervaloTemp = setInterval(atualizarTemp, 1000);
}

function pausarTemp() {
  clearInterval(intervaloTemp);
  intervaloTemp = null;
}

function resetarTemp() {
  pausarTemp();
  configurarTemp();
}

// 📆 DATA E HORA
function atualizarDataHora() {
  const agora = new Date();
  const data = agora.toLocaleDateString('pt-BR');
  const hora = agora.toLocaleTimeString('pt-BR');
  document.getElementById('dataHora').textContent = `${data} • ${hora}`;
}

setInterval(atualizarDataHora, 1000);
atualizarDataHora();